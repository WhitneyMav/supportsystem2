<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WearView</title>
</head>
<body>
<?php
// Validate form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $staffName = $_POST['staffName'];
    $issueDescription = $_POST['issueDescription'];

    // Basic server-side validation
    if (empty($staffName) || empty($issueDescription)) {
        echo "Error: Please fill out all fields.";
        exit;
    }

    // Connect to MySQL database (replace with your database credentials)
    $servername = "localhost";
    $username = "username";
    $password = "password";
    $dbname = "database_name";

    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare SQL statement to insert data into database
    $stmt = $conn->prepare("INSERT INTO it_issues (staff_name, issue_description) VALUES (?, ?)");
    $stmt->bind_param("ss", $staffName, $issueDescription);

    // Execute the statement
    if ($stmt->execute()) {
        echo "Issue reported successfully.";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>
<?php
// Connect to MySQL database
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to retrieve incomplete jobs
$sql = "SELECT id, staff_name, issue_description, report_date FROM it_issues WHERE status = 'incomplete'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<h2>Incomplete Jobs</h2>";
    echo "<ul>";
    while ($row = $result->fetch_assoc()) {
        echo "<li><b>Job ID:</b> " . $row['id'] . "<br>";
        echo "<b>Staff Name:</b> " . $row['staff_name'] . "<br>";
        echo "<b>Issue Description:</b> " . $row['issue_description'] . "<br>";
        echo "<b>Report Date:</b> " . $row['report_date'] . "<br>";
        echo '<form action="update_status.php" method="post">';
        echo '<input type="hidden" name="job_id" value="' . $row['id'] . '">';
        echo '<input type="submit" value="Mark as Complete">';
        echo '</form>';
        echo "</li>";
    }
    echo "</ul>";
} else {
    echo "No incomplete jobs found.";
}

$conn->close();
?>
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['job_id'])) {
    $jobId = $_POST['job_id'];

    // Connect to MySQL database
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare SQL statement to update job status
    $stmt = $conn->prepare("UPDATE it_issues SET status = 'complete' WHERE id = ?");
    $stmt->bind_param("i", $jobId);

    // Execute the statement
    if ($stmt->execute()) {
        echo "Job status updated successfully.";
    } else {
        echo "Error updating job status: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>

</body>
</html>